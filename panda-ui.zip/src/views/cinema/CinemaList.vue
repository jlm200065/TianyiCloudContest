<template>
  <div>
    <!--面包屑导航区域-->
    <div class="board">
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item :to="{ path: '/welcome' }">首页</el-breadcrumb-item>
        <el-breadcrumb-item>影院管理</el-breadcrumb-item>
        <el-breadcrumb-item>影院列表</el-breadcrumb-item>
      </el-breadcrumb>
    </div>

    <!--卡片视图-->
    <el-card class="box-card">
      <el-row :gutter="20">
        <el-col :span="4">
          <el-input v-model="inputCinemaName" placeholder="请输入影院名称" clearable></el-input>
        </el-col>

        <el-col :span="1.5">
          <el-button icon="el-icon-search" @click="getCinemaList">搜索</el-button>
        </el-col>
        <el-col :span="2">
          <el-button type="primary" @click="addDialogVisible = true">添加电影院</el-button>
        </el-col>
      </el-row>



      <!--影厅分类列表-->
      <el-table :data="cinemaList" style="width: 100%" border stripe>
        <el-table-column prop="cinemaId" label="id" width="40"></el-table-column>
        <el-table-column prop="cinemaName" label="影院名称"></el-table-column>
        <el-table-column prop="cinemaAddress" label="地址"></el-table-column>
        <el-table-column prop="cinemaPhone" label="电话"></el-table-column>

        <el-table-column label="操作" width="180">
          <template slot-scope="scope">

            <el-tooltip effect="dark" content="删除电影院" placement="top" :enterable="false" :open-delay="500">
              <el-button type="danger" icon="el-icon-delete" size="mini"
                         @click="deleteCinema(scope.row.cinemaId)"></el-button>
            </el-tooltip>
            <el-tooltip effect="dark" content="选中管理" placement="top" :enterable="false" :open-delay="500">
              <el-button :type="scope.row.cinemaId === cinemaId ? 'success' : 'info' " icon="el-icon-s-opportunity" size="mini"
                         @click="changeCinemaIdInStore(scope.row.cinemaId)"></el-button>
            </el-tooltip>
          </template>
        </el-table-column>
      </el-table>

      <!--分页区域-->
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="queryCinema.pageNum"
        :page-sizes="[5, 7, 9]"
        :page-size="queryCinema.pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>

    </el-card>

    <!--添加电影院对话框-->
    <el-dialog title="添加影厅" :visible.sync="addDialogVisible" width="60%" @close="addDialogClosed">
      <!--内容主题区-->
      <el-form :model="addCinemaForm" :rules="addCinemaFormRules" ref="addFormRef" label-width="100px">
        <!--prop：在addCinemaFormRules中定义校验规则， v-model：双向绑定数据-->
        <el-form-item label="电影院名称" prop="cinemaName">
          <el-input v-model="addCinemaForm.cinemaName"></el-input>
        </el-form-item>
        <el-form-item label="电影院地址" prop="cinemaAddress">
          <el-input v-model="addCinemaForm.cinemaAddress"></el-input>
        </el-form-item>
        <el-form-item label="电影院电话" prop="cinemaPhone">
          <el-input v-model="addCinemaForm.cinemaPhone"></el-input>
        </el-form-item>
      </el-form>
      <!--底部区域-->
      <span slot="footer" class="dialog-footer">
      <el-button @click="addDialogVisible = false">取 消</el-button>
      <el-button type="primary" @click="addCinema">确 定</el-button>
      </span>
    </el-dialog>




  </div>
</template>

<script>
import global from "../../assets/css/global.css"
export default {
  name: "CinemaList",
  data() {
    return {

      queryCinema: {
        cinemaName: '',
        pageNum: 1,
        pageSize: 7
      },




      cinemaList: [],

      cinemaId: 0,

      cinemaInfo: {},
      total: 0,
      url: 'http://localhost:8181/',
      //控制对话框的显示与隐藏
      addDialogVisible: false,


      //添加电影院的表单数据
      //write by jlm
      addCinemaForm: {
        cinemaId: '',
        cinemaName: '',
        cinemaAddress: '',
        cinemaPhone:''
      },





      //验证表单规则对象
      //write by jlm
      addCinemaFormRules: {
        CineName: [
          { required: true, message: '请输入电影院名称', trigger: 'blur' }
        ],
      },






      editDialogVisible: false,
      editForm: {},
      checkAbleId: {},
      editFormRules: {
        cinemaName: [
          { required: true, message: '请输入电影院名称', trigger: 'blur' }
        ],
      },

      inputCinemaName: '',


      arrangeDialogVisible: false,

      arrangeDialogWidth: '',
      // loginUser: JSON.parse(window.sessionStorage.getItem('loginUser')),
      // curCinemaName: ''
    }
  },
  created() {

    //written by jlm
    this.getCinemaList()
    this.getCinemaId()

  },
  methods: {





    changeCinemaIdInStore(id){

        this.$store.commit('setCinemaId', id)
        this.getCinemaId()

    },



    getCinemaId(){
      this.cinemaId = this.$store.state.CinemaId
    },


    getCinemaList(){
      this.queryCinema.cinemaName = this.inputCinemaName
      const _this = this;
      axios.get('sysCinema/all', {params: _this.queryCinema}).then(resp => {
        _this.cinemaList = resp.data.data;
        _this.total = resp.data.total;
        _this.queryCinema.pageSize = resp.data.pageSize;
        _this.queryCinema.pageNum = resp.data.pageNum;
        console.log(_this.cinemaList)

      })

    },




    handleSizeChange(newSize) {
      this.queryCinema.pageSize = newSize
      this.getCinemaList()
      console.log(newSize)
    },
    handleCurrentChange(newPage) {
      this.queryCinema.pageNum = newPage
      this.getCinemaList()
      console.log(newPage)
    },
    // 监听添加对话框的关闭事件
    addDialogClosed(){
      this.$refs.addFormRef.resetFields()
    },


    addCinema(){
      const _this = this;
      this.$refs.addFormRef.validate(async valid => {
        console.log(valid)
        if (!valid) return
        //预校验成功，发网络请求
        axios.defaults.headers.post['Content-Type'] = 'application/json'
        console.log(_this.addCinemaForm.phone)
        const {data : res } = await axios.post('sysCinema', JSON.stringify(_this.addCinemaForm))
        if(res.code !== 200) return this.$message.error("添加电影院失败 " + res.msg)
        //隐藏添加对话框
        this.addDialogVisible = false
        //重新加载列表
        this.getCinemaList()
        this.$message.success('添加电影院信息成功！')
      })
    },







    // 监听修改对话框的关闭事件
    editDialogClosed(){
      this.$refs.editFormRef.resetFields()
    },





    async deleteCinema(id){

      if (id === 1){
        this.$message.success("1号初始测试数据不可删除！")
        return
      }
      await axios.delete('sysCinema/'+id).then(resp => {
        if (resp.data.code !== 200){
          this.$message.success('删除电影院失败！')
        }
      })
      this.getCinemaList()
      this.$message.success('删除电影院成功！')
    },




  }
}
</script>

<style scoped>



</style>
