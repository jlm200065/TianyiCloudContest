<template>

</template>

<script>
export default {
  name: "Welcome"
}
</script>

<style scoped>


</style>