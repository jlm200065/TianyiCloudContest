<template>
<div>


  <div class="money-info-container">
    <div style="width: 70%">
      <el-form :model="loginUser"   label-width="80px">
        <el-form-item label="钱包余额" prop="money">
          <el-input v-model="loginUser.money" disabled></el-input>
        </el-form-item>
        <el-button type="primary" @click="showRechargeDialog = true">充值</el-button>
      </el-form>
    </div>
  </div>



  <!--添加电影院对话框-->
  <el-dialog title="余额充值" :visible.sync="showRechargeDialog" width="60%" @close="showDialogClosed">
    <!--内容主题区-->
    <el-form :model="moneyForm" :rules="moneyFormRules"  ref="showFormRef" label-width="100px">
      <el-form-item label="充值金额：" prop="money">
        <el-input v-model="moneyForm.money"></el-input>
      </el-form-item>
    </el-form>
    <!--底部区域-->
    <span slot="footer" class="dialog-footer">
      <el-button @click="showRechargeDialog = false">取 消</el-button>
      <el-button type="primary" @click="rechargeMoney">确 定</el-button>
      </span>
  </el-dialog>
</div>


</template>

<script>

export default {
  name: "MoneyInfo",
  data() {
    return {
      loginUser:{},
      showRechargeDialog: false,
      moneyForm:{
        money: ''
      },


      moneyFormRules: {
        money: [
          { required: true, message: '请输入合法正整数', trigger: 'blur' },
          { validator: this.isNumber, trigger: 'blur'}
        ],

      }
    }
  },
  created() {
    this.getUser()
  },
  methods: {






    async getUser(){
      const { data : res } = await axios.get('sysUser/'+JSON.parse(window.sessionStorage.getItem('loginUser')).userId)
      this.loginUser = res.data
      console.log("im here!!!")
      console.log(this.loginUser)
    },

    showDialogClosed(){
      this.$refs.showFormRef.resetFields()
    },
    rechargeMoney(){
      const _this = this;
      this.$refs.showFormRef.validate(async valid => {
        console.log(valid)
        if (!valid) return
        //预校验成功，发网络请求

        this.loginUser.money = String(Number(this.loginUser.money) + Number(this.moneyForm.money))

        axios.defaults.headers.put['Content-Type'] = 'application/json'
        const {data : res } = await axios.put('sysUser/updateMoney', JSON.stringify(this.loginUser))
        if(res.code !== 200) return this.$message.error("充值失败" + res.msg)
        //隐藏添加对话框
        this.showRechargeDialog = false
        //重新加载列表
        this.getUser()
        this.$message.success('充值成功！')
      })
    },
    isNumber(rule, value, callback) {
      if (value === '') {
        return callback();
      }  //这是用来判断如果不是必须输入的，则直接跳出
      const r = /^\+?[1-9][0-9]*$/; // 正整数
      // 如果判断不符合正则，则不是正整数不能提交
      if (!r.test(value)) {
        return callback(new Error('充值金额必须为正整数'));
      } else {
        return callback();
      }
    }
  }
}
</script>

<style scoped>
.money-info-container{
  display: flex;
}
</style>
