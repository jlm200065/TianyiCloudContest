<template>
  <div class="message-list-container">
    <div class="profile-title">我的纸条</div>
    <div class="order-box" v-for="item in messageList">
      <div class="order-header">
        <span class="order-date">纸条时间：{{item.createTime}}</span>
        <span class="order-date">纸条编号: {{item.messageId}}</span>
        <span class="order-date">
          <h4 v-if="item.toId === userId">你收到的！</h4>
          <h4 v-else>你发出的~</h4>
        </span>
        <p class="p1">
          {{item.content}}
        </p>
        <h4></h4>
        <div class="order-status">
          <span v-if="item.toId === userId">
                <el-button type="primary" @click="seePaidUser(item.fromId)">查看是谁</el-button>
          </span>
          <span v-else>
                <el-button type="primary" @click="seePaidUser(item.toId)">查看是谁</el-button>
          </span>

        </div>

      </div>
    </div>


    <!--异构座位的用户信息  对话框-->
    <el-dialog title="购买此座位的用户信息" :visible.sync="DialogVisible" width="27%" height="20%">
      <!--内容主题区-->

      <div class="card">
        <div class="circle">
          <div class="imgBx">
            <img :src="url" alt="">
          </div>
        </div>
        <div class="content">
          <h2>{{ paidUser.userName }}</h2>
          <h4 v-if="paidUser.sex">♂ {{ paidUser.birthday }}</h4>
          <h4 v-else>♀ {{ paidUser.birthday }}</h4>
          <div class="textIcon">
            <h4>{{ paidUser.autograph }}</h4>
            <a href="#"><i class="fa fa-arrow-right" aria-hidden="true"></i></a>
          </div>
        </div>
      </div>

      <!--底部区域-->
      <span slot="footer" class="dialog-footer">
      <el-button @click="DialogVisible = false">我知道啦</el-button>
      <el-button @click="MessageVisible = true">发消息给ta~</el-button>

      </span>
    </el-dialog>




    <!--发小纸条 对话框-->
    <el-dialog title="小纸条" :visible.sync="MessageVisible" width="27%" height="20%" @close="messageDialogClosed">
      <!--内容主题区-->
      <el-form :model="messageForm" :rules="messageFormRules" ref="addFormRef" label-width="100px">
        <!--prop：在messageFormRules中定义校验规则， v-model：双向绑定数据-->
        <el-form-item label="小纸条~" prop="content">
          <el-input v-model="messageForm.content"></el-input>
        </el-form-item>

      </el-form>
      <!--底部区域-->
      <span slot="footer" class="dialog-footer">
      <el-button @click="MessageVisible = false">取 消</el-button>
      <el-button type="success" @click="sendMessage">递给ta~</el-button>
      </span>
    </el-dialog>



  </div>
</template>

<script>
import moment from 'moment'

export default {
  name: "MessageList",
  data() {
    return {
      queryInfo: {
        userId: ''
      },
    userId: '',
      url: '',
      //添加电影院的表单数据
      //write by jlm
      messageForm: {
        fromId: '',
        toId: '',
        content:'',
      },

      messageFormRules: {
        content: [
          { required: true, message: '快填写您递给ta的小纸条吧！', trigger: 'blur' }
        ],
      },


      DialogVisible: false,

      MessageVisible: false,

      //某个已购座位上的用户
      paidUser: '',



      messageList: [
        {
            messageId: '',
            fromId: '',
            toId: '',
            content: '',
            createTime: ''

        }
      ]


    }
  },
  created() {
    this.getUser()
    this.getMessageList()
  },
  methods: {
    getUser() {
      this.queryInfo.userId = JSON.parse(window.sessionStorage.getItem('loginUser')).userId
      this.userId = this.queryInfo.userId
    },

    async getMessageList() {
      const _this = this
      await axios.get('SysMessage/'+this.queryInfo.userId).then(resp=>{
        console.log("信息列表:")
        console.log(resp.data.data)
        _this.messageList = resp.data.data
        _this.messageList = _this.messageList.reverse()

      })
    },

    sendMessage(){
      const _this = this;
      this.$refs.addFormRef.validate(async valid => {

        if (!valid) return
        //预校验成功，发网络请求
        axios.defaults.headers.post['Content-Type'] = 'application/json'

        const {data : res } = await axios.post('SysMessage', JSON.stringify(_this.messageForm))
        if(res.code !== 200) return this.$message.error("发送失败 " + res.msg)
        //隐藏添加对话框
        this.MessageVisible = false

        this.$message.success('发送成功！')
      })
    },


    async seePaidUser(id){


      const { data : res } = await axios.get('seeOtherUser/'+ id)
      this.paidUser = res.data
      console.log("已购买该座位的用户在这！" + this.paidUser.userId)


      let picture = JSON.parse(this.paidUser.userPicture)
      this.url = this.global.base + picture[0]

      this.messageForm.toId = id
      this.messageForm.fromId = this.userId

      this.DialogVisible = true
    },



  }
}
</script>

<style scoped>
.message-list-container{
  min-height: 900px;
}

.profile-title {
  padding: 26px 0;
  color: #ec443f;
  font-size: 18px;
  border-bottom: 1px solid #e1e1e1;
  margin-bottom: 30px;
}

.order-box {
  border: 1px solid #e5e5e5;
  margin: 0 40px 30px 0;
}

.order-box .order-header {
  background-color: #f7f7f7;
  font-size: 14px;
  padding: 16px 20px;
}

.order-box .order-header .order-date {
  color: #333;
  display: inline-block;
  margin-right: 30px;
}

.order-box .order-header .order-id {
  color: #999;
}
.p1{
  color: orangered;
  font-weight: bolder;
}
.del-order{
  float: right;
}

.order-box .order-body {
  padding: 20px;
  padding-right: 0;
  display: flex;
}

.order-box .order-body .poster {
  width: 66px;
  height: 91px;
  margin-right: 11px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, .12), 0 0 6px rgba(0, 0, 0, .04)
}

.poster img{
  width: 100%;
  height: 100%;
}

.order-content{
  width: 49%;
}

.movie-name{
  font-size: 16px;
  font-weight: 700;
  color: #333;
  margin: 4px 0 7px -6px;
}

.cinema-name, .hall-ticket {
  font-size: 12px;
  color: #999;
  margin-bottom: 4px;
}

.show-time {
  font-size: 12px;
  color: #f03d37;
}

.order-price, .order-status, .actions{
  font-size: 14px;
  color: #333;
  width: 15%;
  line-height: 95px;
}
.order-detail {
  color: #2d98f3;
}
a {
  text-decoration: none;
  cursor: pointer;
  color: #333;
}







.card{
  position: relative;
  width: 340px;
  height: 450px;
  border-radius: 10px;
  overflow: hidden;
  background: #fff;
}
.circle{
  position: absolute;
  top: -190px;
  left: 50%;
  transform: translateX(-50%);
  width: 500px;
  height: 500px;
  background: #333;
  clip-path: circle();
}
.circle:before{
  content: '';
  position: absolute;
  top: -8px;
  left: -16px;
  width: 100%;
  height: 100%;
  background: transparent;
  box-shadow: 0 0 0 20px rgba(255, 0, 0, 0.5);
  border-radius: 50%;
  z-index: 999;
  pointer-events: none;
}
.circle .imgBx{
  position: absolute;
  left: 50%;
  bottom: 0;
  transform: translateX(-50%);
  width: 340px;
  height: 310px;
  background: #ff0;
}
.circle .imgBx img{
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
  transition: 0.5s;
  transform-origin: bottom;
}
.circle .imgBx:hover img{
  transform: scale(1.5);
}
.content{
  position: absolute;
  left: 0;
  bottom: 0;
  width: 100%;
  height: 140px;
  padding: 20px 30px;
}
.fa-linkedin{
  color: #fff;
  background: #0077b5;
  padding: 2px 4px;
  border-radius: 2px;
}
#content h3{
  font-size: 1.4em;
  color: #333;
  margin-top: 7px;
}
.textIcon{
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
  padding: 0 2px;
}
.textIcon h4{
  color: #e91e63;
  font-weight: 400;
}
.textIcon a{
  color: #e91e63;
  text-decoration: none;
}


</style>
