<template>
  <div>
    <!-- 轮播图 -->
    <el-carousel :height="carouselHeight">
      <el-carousel-item v-for="item in posterList" :key="item.url">
        <img :src="item.url" alt/>
      </el-carousel-item>
    </el-carousel>
    <div class="whole">




      <div class="left">
        <h2 style="color: #494608">影院信息</h2>
        <div class="panel">
          <div class="panel-header">

            <!--卡片视图-->
            <el-card class="box-card">
              <!--表格显示影院信息-->
              <el-form :model="cinemaInfo" label-width="150px">
                <el-form-item label="影院名称: " prop="cinemaName">
                  <el-input class="el-input-show" v-model="cinemaInfo.cinemaName" disabled></el-input>
                </el-form-item>
                <el-form-item label="影院地址: " prop="cinemaAddress">
                  <el-input class="el-input-show" v-model="cinemaInfo.cinemaAddress" disabled></el-input>
                </el-form-item>
                <el-form-item label="影院电话: " prop="cinemaPhone">
                  <el-input class="el-input-show" v-model="cinemaInfo.cinemaPhone" disabled></el-input>
                </el-form-item>
                <el-form-item label="营业时间: " prop="cinemaPhone">
                  <el-input class="el-input-show-time" v-model="cinemaInfo.workStartTime" disabled></el-input>
                  至
                  <el-input class="el-input-show-time" v-model="cinemaInfo.workEndTime" disabled></el-input>
                </el-form-item>
                <el-form-item label="拥有影厅类型: " prop="hallCategory">
                  <el-tag v-for="hall in halls" >{{hall}}</el-tag>
                </el-form-item>
                <el-form-item label="影院图片: ">
          <span v-for="item in pics">
            <el-popover placement="left" trigger="click" width="300">
              <img :src="item.url" width="200%"/>
              <img slot="reference" :src="item.url" :alt="item"
                   style="max-height: 300px;max-width: 300px;padding: 10px"/>
            </el-popover>
          </span>
                </el-form-item>

              </el-form>
            </el-card>


          </div>
        </div>


        <div class="panel">
          <div class="panel-header">
            <h2 style="color: #ef4238">正在热映</h2>
            <a href="/movie/movieOngoing">全部</a>
          </div>
          <div class="panel-content">
            <movie-item :movieItem="item" v-for="(item, index) in ongoingMovieList" :key="index"></movie-item>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">
            <h2 style="color: #2d98f3">即将上映</h2>
            <a href="/movie/movieUpcoming">全部</a>
          </div>
          <div class="panel-content">
            <div class="panel-content">
              <movie-item :movieItem="item" v-for="(item,index) in upcomingMovieList" :key="index"></movie-item>
            </div>
          </div>
        </div>
        <div class="panel">
          <div class="panel-header">
            <h2 style="color: #ef4238">经典影片</h2>
            <a href="/movie/movieClassics">全部</a>
          </div>
          <div class="panel-content">
            <div class="panel-content">
              <movie-item :movieItem="item" v-for="(item,index) in classicMovieList" :key="index"></movie-item>
            </div>
          </div>
        </div>
      </div>
      <div class="right">
        <div class="panel">
          <div class="panel-header">
            <h2 style="color: #ffb400">票房榜</h2>
            <a href="/rankingList/totalBoxOfficeList">查看完整榜单</a>
          </div>
          <div class="panel-content">
            <div class="board" v-for="(item, index) in totalBoxOfficeList">
              <div class="board-left">
                <i class="board-index">{{index+1}}</i>
              </div>
              <div class="board-middle">
                <a :href="'/movieInfo/' + item.movieId">
                  <p class="name">{{ item.movieName }}</p>
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import movieItem from '../../components/movie/movie-item'
import moment from 'moment'
export default {
  name: "Home",
  components: {
    movieItem
  },
  data() {
    return {


      //当前电影院信息
      cinemaInfo: {},
      cinemaId: 1,
      //添加删除图片 动态绑定图片列表
      pics: [],
      //添加删除影厅类别 动态绑定影厅列表
      halls: [],
      // 发送给后端的JSON图片数组
      pictureList: [],
      picNums: 0,
      deletePicList: [],





      queryInfo1: {
        total: 0,
        pageSize: 8,
        pageNum: 1,
        startDate: moment().subtract(30, "days").format("YYYY-MM-DD"),
        endDate: moment().format('YYYY-MM-DD'),
      },
      queryInfo2: {
        total: 0,
        pageSize: 8,
        pageNum: 1,
        startDate: moment().format('YYYY-MM-DD')
      },
      queryInfo3: {
        total: 0,
        pageSize: 8,
        pageNum: 1
      },
      queryInfo4:{
        pageSize: 10,
        pageNum: 1
      },
      posterList: [
        {url: require('../../assets/carousel1.jpg')},
        {url: require('../../assets/carousel2.jpg')},
        {url: require('../../assets/carousel3.jpg')},
        {url: require('../../assets/carousel4.jpg')}
      ],
      ongoingMovieList: [],
      upcomingMovieList: [],
      classicMovieList: [],
      carouselHeight: '',
      totalBoxOfficeList: []
    }
  },
  created() {

    this.getCinemaId()
    this.getCinemaInfo()

    this.getOngoingMovieList()
    this.getUpcomingMovieList()
    this.getClassicMovieList()
    this.getHeight()
    this.getTotalBoxOfficeList()
  },
  methods:{


    async getCinemaInfo() {
      const _this = this
      await axios.get('sysCinema/'+this.$store.state.CinemaId).then(resp => {
        _this.cinemaInfo = resp.data.data
      })
      _this.pics = []
      _this.halls = []

      for (const item of JSON.parse(this.cinemaInfo.cinemaPicture)) {
        let pic = {}
        pic['name'] = ''
        pic['url'] = this.global.base + item
        this.pics.push(pic)
      }
      for (const item of JSON.parse(this.cinemaInfo.hallCategoryList)) {
        this.halls.push(item)
      }
    },




    getCinemaId(){
      this.cinemaId = this.$store.state.CinemaId
    },
    changeCinemaIdInStore(id){

      this.$store.commit('setCinemaId', id)
      this.getCinemaId()
      this.getCinemaInfo()

    },





    async getOngoingMovieList() {
      const { data : res } = await axios.get('sysMovie/find', {params: this.queryInfo1})
      this.ongoingMovieList = res.data
      this.total = res.total
    },
    async getUpcomingMovieList() {
      const {data: res} = await axios.get('sysMovie/find', {params: this.queryInfo2})
      this.upcomingMovieList = res.data
      this.total = res.total
    },
    async getClassicMovieList() {
      const { data : res } = await axios.get('sysMovie/find', {params: this.queryInfo3})
      this.classicMovieList = res.data
      this.total = res.total
    },
    getHeight() {
      let clientWidth =   `${document.documentElement.clientWidth}`
      clientWidth *= 0.8
      this.carouselHeight = clientWidth / 1700 * 520 + 'px'
    },
    async getTotalBoxOfficeList(){
      const {data: resp} = await axios.get('sysMovie/find/rankingList/1', {params: this.queryInfo})
      console.log(resp)
      if(resp.code !== 200) return this.$message.error(resp.msg)
      this.totalBoxOfficeList = resp.data
    }
  },
  watch: {
    "$store.state.CinemaId":{
      handler:function(){
        console.log("im watch, and im changed")
        this.getCinemaId()
        this.getCinemaInfo()
      }
    }
  }
}
</script>

<style scoped>

.el-carousel {
  width: 80%;
  margin: 30px auto;
}

.el-carousel__item > img {
  width: 100%;
  height: auto;
}

.whole{
  width: 1200px;
  margin: 30px auto;
  display: flex;
}

.left{
  width: 70%;
}

.right{
  width: 30%;
  margin-left: 100px;
}

h2{
  font-size: 26px;
}

.panel-header > a{
  text-align: center;
  text-decoration: none;
  color: #999;
  padding-right: 14px;
  /*background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAOCAYAAAASVl2WAAAABmJLR0QA/wD/AP+gvaeTAAAAv0lEQVQY013RTUpDQRAE4G8eghcR8ScgKCIugpJFjuIjqAvBc7jxj0muEnCjiIQQJOImB3GnbnpkfL1qpqqrunpSzvkDPxjhGdq2VarBF3q4wRHknP8RzvCEQzzguCalaHZwiwHecY6XogCf8TjFHh7Rh9Tx3AylIZa4TgWpSBuY4BSrYlFXKsr4bjrTW5HkJJa9SBW4jbtukmKxG5MDLOKqfzEPcB9LzQN8LSdfwxj7eMMlZvV/NFiPzFddEH4Bt5Y1mf3fnDwAAAAASUVORK5CYII=) no-repeat 100%*/
}


.panel-header{
  display: flex;
  justify-content: space-between;
  align-items: center;
  /*margin-right: 20px;*/
  /*margin-left: 20px;*/
}

.movie-item{
  margin-left: 0;
  margin-right: 30px;
}

.movie-item:nth-child(4n){
  margin-right: 0;
}

.board{
  display: flex;
  margin: 10px 10px;
}

.board-left{
  display: flex;
  align-items: center;
}

.board-middle{
  display: flex;
  /*align-items: center;*/
  /*justify-content: center;*/
  margin-left: 10px;
  width: 150px;
  font-size: 18px;
}

.board-middle > a{
  text-decoration: none;
  color: #333;
}

.board-right{
  display: flex;
  font-size: 14px;
  font-weight: 700;
  color: #ffb400;
  margin-left: 40px;
  align-items: center;
}

.board-index{
  color: #ffb400;
  display: inline-block;
  width: 50px;
  height: 50px;
  line-height: 50px;
  text-align: center;
  font-size: 18px;
  /*font-weight: 700;*/
  align-items: center;
}

.panel-content{
  margin: 0px 0px 50px 0px;
}

</style>
