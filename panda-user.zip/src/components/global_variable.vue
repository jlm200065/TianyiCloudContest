
<script>
const base = 'http://127.0.0.1:8070/'
// const pic  = 'http://127.0.0.1:8070/'

export default {
  base,
  // pic
}

</script>
