import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

export default new Vuex.Store({
  state: {

    CinemaId: 1
  },
  mutations: {
    setCinemaId(state, cinemaId){
      state.CinemaId = cinemaId;
    }
  },
  actions: {
  },
  modules: {
  }
})
